/**
	the package
*/
package kr.ac.kookmin.cs;

/**
	the class, the class
*/
public class PPoint {
	int xA;
	int yA;
	
	/**
		mothod 1
	*/
	public PPoint(int x, int y) {
		xA = x;
		yA = y;
	}

	/**
		mothod 2
	*/
 	public int getX() {
 	return xA;
 	}

	/**
		method 3
	*/
	public int getY() {
		return yA;
	}
}
